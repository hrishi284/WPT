alert("this is a pure JS file without html");
