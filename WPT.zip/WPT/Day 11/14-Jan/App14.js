import HttpGetEx from "./httpGetex";
import PostHttpEx from "./PostHttpEx";

export default function App14()
{



    return (
        <div>
        <h1>Testing http</h1>
        <HttpGetEx></HttpGetEx>
        <PostHttpEx></PostHttpEx>
        </div>
    )
}