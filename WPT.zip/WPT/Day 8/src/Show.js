import { Component } from "react";

export default class Show extends Component
{
    render()
    {
        return(
            <div>
                Name : Prachi
                Address : Pune
            </div>
        )
    }
}