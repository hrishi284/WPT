export default function Welcome(props)
{
    return (
        <h4> Welcome {props.fname}</h4>
    )
}