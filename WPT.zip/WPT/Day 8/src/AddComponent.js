export default function AddComponent(){
   return(
    <>
      <input type="text" />
      <button >OK</button>
    </>
   )
}//end of AddComponent

export function SayHi()
{
    return(<h4>Hi.....</h4>)
}//end of SayHi Component

export function SayBye()
{
    return (<h3>Bye...</h3>)
}//end of SayBye

// export {SayHi,SayBye}
// export default AddComponent