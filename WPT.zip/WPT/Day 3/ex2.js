var x =45
console.log(x,typeof(x))

x="hello"
console.log(x,typeof(x))

x=45.99
console.log(x,typeof(x))

x=true
console.log(x,typeof(x))

//x='W'c
x='Wire'
x="cable"
x=`this is a long string that 
goes on the new line`
var y=30
x=`there are `+y+" roses in the garden"
x=`there are ${y} roses in the garden`
console.log(x,typeof(x))

let p = 5.6
console.log(p)

const d = 7.8
//d=5
console.log(d)






