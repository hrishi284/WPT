/*
let x = 10
console.log(x)
let x = 20
console.log(x)
*/

console.log(x)
let x
