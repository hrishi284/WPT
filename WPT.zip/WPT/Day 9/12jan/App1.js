import C1 from "./C1"
import EventEx from "./EventEx"
import EventExC from "./EventExC"
import ShoppingList from "./ShoppingList"
import ShowCaps from "./ShowCaps"
import ShowCapsC from "./ShowCapsC"
export default function App1()
{
    return(
        <>
        <ShoppingList></ShoppingList>
        {/*<ShowCapsC></ShowCapsC>
        <ShowCaps></ShowCaps>
         <EventEx></EventEx>
        <EventExC></EventExC>
        <C1></C1>*/}
        </> 
    )
}