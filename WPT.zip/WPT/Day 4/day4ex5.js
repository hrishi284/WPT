function sum(n1=0,n2=0,n3=0)
{
    let dbl= 2*n2
    let tpl= 3*n3
    return (n1+dbl +tpl)
}
console.log(sum())
console.log(sum(12))
console.log(sum(12,13))
console.log(sum(12,13,14))
//console.log(sum())