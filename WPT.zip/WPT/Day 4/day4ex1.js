let str='flower'
//let rv = str.charAt(2)
//let rv = str.length

// string is immutable 
//let rv = str.concat("is red "," it may be a rose")
//let rv = str.toUpperCase()
//let rv = str.slice(2) //str.slice(0,4) , str.slice()

//let rv = str.substring(0,4)

//let rv = str.split('o')
let rv = str.endsWith('ing')
console.log("rv=",rv," original-string=",str)
