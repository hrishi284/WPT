function add(n1,n2,n3)
{
    let sum = n1+n2+n3
    console.log("sum=",sum)
}
function add(n1,n2)
{
    let sum = n1+n2
    console.log("sum2=",sum)
}

add(10,20,30)
add(10,20)
add(10)
add()
add(5,4,3,2,1)